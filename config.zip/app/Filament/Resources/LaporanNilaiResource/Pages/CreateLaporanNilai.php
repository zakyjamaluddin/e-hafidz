<?php

namespace App\Filament\Resources\LaporanNilaiResource\Pages;

use App\Filament\Resources\LaporanNilaiResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateLaporanNilai extends CreateRecord
{
    protected static string $resource = LaporanNilaiResource::class;
}
