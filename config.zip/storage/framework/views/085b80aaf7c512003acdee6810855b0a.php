<?php if (! $__env->hasRenderedOnce('5b33492c-313d-449a-9619-08ed27c20dea')): $__env->markAsRenderedOnce('5b33492c-313d-449a-9619-08ed27c20dea'); ?>
    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/custom-font.css')); ?>">
    <?php $__env->stopPush(); ?>
<?php endif; ?>


<div 
    x-data="{
        page: <?php echo e($page ?? 1); ?>,
        juz: <?php echo e($juz ?? 1); ?>, // ← tambahkan ini
        ayahs: <?php echo \Illuminate\Support\Js::from($ayahs)->toHtml() ?>,
        loading: false,
        async fetchAyat() {
            this.loading = true;
            try {
                let url = '';
                if (this.juz === 30) {
                    // Contoh: Tampilkan surah terakhir (An-Nas)
                    url = `https://api.alquran.cloud/v1/surah//${this.page}`;
                } else {
                    url = `https://api.alquran.cloud/v1/page/${this.page}/quran-uthmani`;
                }

                const res = await fetch(url);
                const data = await res.json();

                // Jika API surah, ambil `data.ayahs`, bukan `data.data.ayahs`
                this.ayahs = this.juz === 30 ? data.data.ayahs : data.data.ayahs;
            } catch (e) {
                this.ayahs = [];
            } finally {
                this.loading = false;
            }
        },
        arabicNumber(number) {
            const western = ['0','1','2','3','4','5','6','7','8','9'];
            const eastern = ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
            return String(number).split('').map(d => eastern[western.indexOf(d)]).join('');
        }



    }"
    x-init="
        // Dengarkan event dari Select Filament
        window.addEventListener('halaman-changed', e => {
            page = e.detail.page;
            juz  = e.detail.juz;
            fetchAyat();
        });
    "
    class="p-4 space-y-4 text-right"
    dir="rtl"
>

    <?php
    if (!function_exists('arabic_number')) {
        function arabic_number($number)
        {
            $western = ['0','1','2','3','4','5','6','7','8','9'];
            $eastern = ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
            return str_replace($western, $eastern, $number);
        }
    }
    ?>
    <!-- Tampilkan Ayat -->
    <div class="text-2xl leading-loose text-justify min-h-[300px]" style="font-family: 'Arabic'">
        <template x-if="ayahs.length > 0">
            <div>
                <template x-for="ayah in ayahs" :key="ayah.number">
                    <span class="inline">
                        <span x-text="ayah.text"></span>
                        <span class="inline-flex items-center justify-center w-7 h-7 rounded-full border-2 border-gray-700 text-sm font-bold mx-1">
                            <span x-text="arabicNumber(ayah.numberInSurah)"></span>
                        </span>
                    </span>
                </template>
            </div>
        </template>

        <template x-if="ayahs.length === 0">
            <p class="text-center text-gray-500">Gagal memuat ayat.</p>
        </template>
    </div>

    <!-- Loading -->
    <div x-show="loading" class="text-center text-gray-500">Memuat halaman...</div>

    <!-- Tombol Navigasi -->
    <div class="flex justify-between mt-6">
        <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['color' => 'gray','tag' => 'button','size' => 'sm','xBind:disabled' => 'page <= 1','xOn:click.prevent.stop' => 'page--; fetchAyat()']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'gray','tag' => 'button','size' => 'sm','x-bind:disabled' => 'page <= 1','x-on:click.prevent.stop' => 'page--; fetchAyat()']); ?>
        Halaman Sebelumnya
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['color' => 'gray','tag' => 'button','size' => 'sm','xOn:click.prevent.stop' => 'page++; fetchAyat()']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'gray','tag' => 'button','size' => 'sm','x-on:click.prevent.stop' => 'page++; fetchAyat()']); ?>
        Halaman Berikutnya
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>

    </div>
    <br>
    <hr>

</div>
<?php /**PATH C:\xampp\htdocs\E-Hafidz\resources\views/filament/components/quran-slideover.blade.php ENDPATH**/ ?>